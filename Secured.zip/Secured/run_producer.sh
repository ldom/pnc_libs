#!/usr/bin/env bash

SCRIPT_DIR=$(cd `dirname $0` && pwd)

FILE=$1
STRING=$2

CLASSPATH="$SCRIPT_DIR/encrypted-producer-1.0-2020-05-07.jar"
for f in $SCRIPT_DIR/dependencies/*.jar; 
    do CLASSPATH="$CLASSPATH:$f";
done

java -cp $CLASSPATH io.confluent.samples.laurent.encrypted_producer.ProducerMain $FILE $STRING